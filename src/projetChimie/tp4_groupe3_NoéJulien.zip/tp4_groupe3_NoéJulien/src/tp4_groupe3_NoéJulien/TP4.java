package tp4_groupe3_NoéJulien;

import java.util.Scanner;

public class TP4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner input = new Scanner(System.in);
	        //demande la dimension de la largeur du tableau
			System.out.print("De quelle dimension voulez-vous la largeur de votre tableau?"+"\n");
			int col = input.nextInt();
			
	        //demande la dimension de la longeur du tableau
			System.out.print("De quelle dimension voulez-vous la longeur de votre tableau?"+"\n");
			int row = input.nextInt();
			
			//fait le tableau
			int[][] grid = new int [row][col];
					
			//demande le pourcentage de cellule infecté
			System.out.print("Quelle pourcentage du tableau voulez-vous remplir?"+"\n");
			int nbpourc = input.nextInt();
			
			
			//demande le nombre de génération que l'utilisateur veut passer
			System.out.print("Combien de génération voulez vous passer?"+"\n");
			double nbgen = input.nextInt();

			
			double tauxremplis = (nbpourc/100.0); //met 50% en 0,5
			int tot = row*col; //calcule le nombre totale de cellule
			double population = tauxremplis*100; //trouve le nombre de cellule infecté

			//infecte le noombre de cellule qui doit être infecté
			int sum3 = 0;
			for (int r = 0; r < row ; r++) {
             for (int c = 0; c <col; c++) {
 				if (sum3 <=population)
 					grid[r][c] = 1;
 				sum3++;
 				if (sum3>population)
 					grid[r][c] = 0;
             }
         }
			
			//Imprime le tableau
			System.out.println("Génération Originale (1):");
			for (int i = 0; i < row; i++) {
				for (int j = 0; j < col; j++)
				{
					if (grid[i][j] == 0)
						System.out.print(".");
					else
						System.out.print("*");
				}
				System.out.println();

			}
			System.out.println();
			
			//imprime les prochaines génération
			for (int i = 1; i <= nbgen; i++) {
				System.out.println("Génération: "+(i+1));
			nextGeneration(grid,row,col);
			System.out.println();
			}
			
			}

		// Pour imprimer la prochaine génération   
		 static void nextGeneration(int grid[][], int M, int N) {
			 
			 	//créé un nouveau tableau qui sera la prochaine génération
		        int[][] future = new int[M][N];
				int sum = 0;

		        for (int l = 0; l < M; l++)
		        {

		            for (int m = 0; m < N; m++)
		            {
		                 sum = 0;
		                 
		                if (l !=0  && m !=0) {
		                	if (grid[l-1][m-1] == 1) { //1
		            	sum++;
		                	}
		                }
		                 if (l !=0) {
		                	if (grid[l-1][m] == 1) { //2
		                    sum++;
		                	}
		                 }
		 		                if (l !=0 && m != grid.length-1) { //3
		                	if (grid[l-1][m+1] == 1) {
		                    sum++;
		                	}
		                }
		                
		                if (m != 0){
		                    if(grid[l][m-1] == 1){ //4

		                    sum++;
		                    }
		                }
		                
		                if (m != grid.length-1){
		                    if(grid[l][m+1] ==1){ //6
		                        sum++;
		                    }
		                }
		                
		                if (l != grid.length-1 && m != 0){
		                    if(grid[l+1][m-1] ==1){ //7
			                    sum++;
		                    }
		                }
		                
		                if (l != grid.length-1){
		                    if(grid[l+1][m] == 1){ //8
		                    	sum++;
		                    }
		                }
		                
		                if (l != grid.length-1 && m != grid.length-1){
		                    if(grid[l+1][m+1] == 1){ //9
		                        sum++;
		                    }
		                }
		                
		               //check combien de cellule vivante son autour
		               if (sum <2) {
		            	   future[l][m] = 0;
		               }
		               if (sum  == 2 && future[l][m] ==1 ) {
		            	   future[l][m] = 1;
		               }
		               
		               if (sum>3) {
		            	   future[l][m] = 0;
		               }
		               
		               if (sum == 3) {
		            	   future[l][m] = 1;
		               }
		               
		               if (sum == 3 && grid[l][m] == 0) {
		            	   future[l][m] = 1;
		               }
		        }
		            
		        }
		        //impime le tableau de prochaine génération
		        for (int i = 0; i < M; i++)
		        {
		            for (int j = 0; j < N; j++)
		            {
		                if (future[i][j] == 0)
		                    System.out.print(".");
		                else
		                    System.out.print("*");
		            }
		            System.out.println();
		        }
		    
		     
	     //Met les deux tableau similaire
		 for (int v = 0; v < M; v++)
	        {
	            for (int c = 0; c < N; c++) {
	            	if (future[v][c] ==1) {
	            		grid[v][c] = 1;
	            	}
	            	else if (future[v][c] ==0) {
	            		grid[v][c] = 0;

	            	}
	            }
	        }


		 }
	}